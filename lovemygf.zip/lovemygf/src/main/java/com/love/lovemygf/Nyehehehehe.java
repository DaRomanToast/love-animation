package com.love.lovemygf;

import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.Path2D;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class Nyehehehehe extends JPanel implements ActionListener {

    private int heartProgress = 0;
    private final int maxProgress = 314;
    private final String message = "I Love You (name or whatever the message is optional) My Love:)<3";
    private List<MiniHeart> miniHearts = new ArrayList<>();
    private int messageIndex = 0;
    private boolean imagesVisible = false;

    private Image img1, img2;

    public Nyehehehehe() {
        Timer timer = new Timer(20, this);
        timer.start();

        try {
            img1 = loadImage("/com/love/lovemygf/png1.png");
            img2 = loadImage("/com/love/lovemygf/png2.png");
            if (img1 != null) {
                img1 = img1.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
            }
            if (img2 != null) {
                img2 = img2.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
            }
// put the audio and images in the resources folder you can rename edit them im sure you have a iq above 60

            //btw the audio has to be wav search up mp3 to wav converter unless you want to add dependancy to allow mp3 but im lazy af
            InputStream audioSrc = getClass().getResourceAsStream("/com/love/lovemygf/love_song.wav");
            if (audioSrc != null) {
                InputStream bufferedIn = new BufferedInputStream(audioSrc);
                AudioInputStream audioStream = AudioSystem.getAudioInputStream(bufferedIn);
                Clip clip = AudioSystem.getClip();
                clip.open(audioStream);
                clip.start();
            }
        } catch (IOException | UnsupportedAudioFileException | LineUnavailableException e) {
            e.printStackTrace();
        }

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_R) {
                    heartProgress = 0;
                    messageIndex = 0;
                    imagesVisible = false;
                    miniHearts.clear();
                }
            }
        });
        setFocusable(true);
    }

    private Image loadImage(String path) throws IOException {
        InputStream stream = getClass().getResourceAsStream(path);
        if (stream == null) {
            throw new IOException("Resource not found: " + path);
        }
        return ImageIO.read(stream);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        int width = getWidth();
        int height = getHeight();

        g2d.setColor(Color.BLACK);
        g2d.fillRect(0, 0, width, height);

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2d.setColor(Color.RED);

        Path2D.Double path = new Path2D.Double();
        path.moveTo(width / 2, height / 2);

        for (int i = 0; i < heartProgress; i++) {
            double t = i * 0.02;
            double x = 16 * Math.pow(Math.sin(t), 3);
            double y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
            path.lineTo(width / 2 + 10 * x, height / 2 - 10 * y);
        }

        g2d.draw(path);

        if (heartProgress % 10 == 0 && heartProgress < maxProgress) {
            double t = heartProgress * 0.02;
            double x = 16 * Math.pow(Math.sin(t), 3);
            double y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
            miniHearts.add(new MiniHeart(width / 2 + 10 * x, height / 2 - 10 * y));
        }

        for (MiniHeart miniHeart : miniHearts) {
            miniHeart.draw(g2d);
        }

        g2d.setColor(Color.WHITE);

        if (heartProgress >= maxProgress && messageIndex < message.length()) {
            messageIndex++;
        }
// change font if you want im simple af
        if (messageIndex > 0) {
            g2d.setFont(new Font("Serif", Font.BOLD, 36));
            FontMetrics fm = g2d.getFontMetrics();
            int textWidth = fm.stringWidth(message.substring(0, messageIndex));
            g2d.drawString(message.substring(0, messageIndex), (width - textWidth) / 2, height / 2 + 50);
        }

        if (messageIndex >= message.length()) {
            imagesVisible = true;
        }

        if (imagesVisible) {
            if (img1 != null && img2 != null) {
                int imgWidth = img1.getWidth(this);
                int imgHeight = img1.getHeight(this);
                int imgX1 = width / 2 - imgWidth - 20;
                int imgX2 = width / 2 + 20;
                int imgY = height / 2 + 100;

                g2d.drawImage(img1, imgX1, imgY, this);
                g2d.drawImage(img2, imgX2, imgY, this);
// this is for the + so if you want like d put it in line 1 and a in line 2 so it could be d + a
                g2d.setFont(new Font("Serif", Font.BOLD, 36));
                g2d.drawString("+", (width - g2d.getFontMetrics().stringWidth("+")) / 2, imgY + imgHeight + 40);
                g2d.drawString("", imgX1 + imgWidth / 2 - g2d.getFontMetrics().stringWidth("") / 2, imgY + imgHeight + 80);
                //line 1 above
                g2d.drawString("", imgX2 + imgWidth / 2 - g2d.getFontMetrics().stringWidth("") / 2, imgY + imgHeight + 80);
                //line 2 above
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (heartProgress < maxProgress) {
            heartProgress++;
        }

        for (MiniHeart miniHeart : miniHearts) {
            miniHeart.update();
        }

        miniHearts.removeIf(miniHeart -> miniHeart.alpha <= 0);

        repaint();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Heart Shape Animation");
        Nyehehehehe heartShapeAnimation = new Nyehehehehe();
        frame.add(heartShapeAnimation);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setUndecorated(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    class MiniHeart {
        double x, y;
        int alpha;

        MiniHeart(double x, double y) {
            this.x = x;
            this.y = y;
            this.alpha = 255;
        }

        void update() {
            alpha -= 5;
        }

        void draw(Graphics2D g2d) {
            g2d.setColor(new Color(255, 0, 0, alpha));
            Path2D.Double miniHeartPath = new Path2D.Double();
            miniHeartPath.moveTo(x, y);
            miniHeartPath.curveTo(x - 4, y - 4, x - 8, y + 4, x, y + 8);
            miniHeartPath.curveTo(x + 8, y + 4, x + 4, y - 4, x, y);
            g2d.fill(miniHeartPath);
        }
    }
}
