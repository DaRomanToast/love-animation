module com.love.lovemygf {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.love.lovemygf to javafx.fxml;
    exports com.love.lovemygf;
}